/*package com.niit.shoppingcart1.controller;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.model.User;

@Controller
public class SecurityController {

	@RequestMapping(value={"/","/user**"},method=RequestMethod.GET)
	public ModelAndView home(){
		ModelAndView model=new ModelAndView();
		model.setViewName("index");
		return model;
	}
	
	@RequestMapping(value="/admin**" ,method=RequestMethod.GET)
	public ModelAndView adminPage(){
		ModelAndView model=new ModelAndView();
		model.setViewName("admin");
		return model;
	}*/
	
/*	@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView login(@RequestParam(value="error",required=true)String error,@RequestParam(value="logout",required=false)String logout){
		ModelAndView model=new ModelAndView();
		if(error!=null){
			model.addObject("error", "Invalid Credentials");
		}
		if(logout!=null){
			model.addObject("msg", "You have logged out successfully");
		}
		model.setViewName("login");
		return model;
	}*/
	
	
	
/*	@RequestMapping(value="/403" ,method=RequestMethod.GET)
	public ModelAndView accessDenied(){
		ModelAndView model=new ModelAndView();
		
		Authentication auth=SecurityContextHolder.getContext().getAuthentication();
		if(!(auth instanceof AnonymousAuthenticationToken)){
			User userDetail=(User) auth.getPrincipal();
			System.out.println(userDetail);
			model.addObject("username", userDetail.getName());
		}
		
		
		model.setViewName("403");
		return model;
	}
}*/
