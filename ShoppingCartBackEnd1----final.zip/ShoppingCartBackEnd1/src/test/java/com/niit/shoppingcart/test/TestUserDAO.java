/*package com.niit.shoppingcart.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.UserDetails;

public class TestUserDAO {

	@Autowired
	static UserDetails userDetails;
	
	@Autowired
	static UserDAO userDAO;
	
	static AnnotationConfigApplicationContext context;
	
	@Before
	public static void init()
	{
		System.out.println("Init method");
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		userDAO=(UserDAO) context.getBean("userDAO");
		userDetails=(UserDetails) context.getBean("userDetails");
	}
	
	@AfterClass
	public static void close()
	{
		context.close();
		userDAO=null;
		userDetails=null;
	}
	
	@Test
	public void UsersTestCase()
	{
		int size= userDAO.list().size();
		assertEquals("User list test case",4,size);
	}
	
//	@Test
//	public void UserNameTestCase()
//	{
//		
//		userDetails=
//		String name=userDetails.getName();
//		
//		assertEquals("Name test case", "niit",name);
//	}
	
}
*/