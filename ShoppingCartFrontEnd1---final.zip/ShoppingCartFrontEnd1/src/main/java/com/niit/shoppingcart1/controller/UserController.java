package com.niit.shoppingcart1.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.User;


@Controller
public class UserController {
	@Autowired
	private CartDAO cart;
	
	@Autowired
	private CartDAO cartDAO;
	
	@Autowired
	Category category;
	
	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	User user;
	
	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session){
		
		ModelAndView mv=new ModelAndView("/index");
		session.setAttribute("category",category);
		session.setAttribute("categoryList", categoryDAO.list());
		return mv;
		
	}


	
	
	
	
	
	
	
	

	@RequestMapping("/about")
	public String getAbout() {
		System.out.println("about page is loaded");
		return "about";
	}

	@RequestMapping("/contact")
	public String getContactus() {
		System.out.println("contact us page is loaded");
		return "contact";
	}
	
	

	
	/*@RequestMapping("/login")
	public String getLogin()
	{
		System.out.println("Login page is loaded");
		return "login";
	}
	
	
	
	@RequestMapping("/signup")
public ModelAndView signup(){
		ModelAndView mv=new ModelAndView("/index");
		mv.addObject("userDetails", userDetails);
		mv.addObject("isUserClickedRegisterHere", "true");
		return mv;
	}
	
	/*@RequestMapping("/check")
	public ModelAndView login(@RequestParam(name="name")String name,@RequestParam(name="password")String password ,HttpSession session){
		ModelAndView mv;
		
		boolean isValidUser=userDAO.isValidUser(name, password);
		
		
		if(isValidUser){
			
			
			userDetails=userDAO.getUser(name);
			session.setAttribute("loggedInUser",userDetails.getName());
			session.setAttribute("loggedInUserID",userDetails.getId());
			
			
			if(userDetails.getAdmin()==1){
				mv=new ModelAndView("/adminHome");
				mv.addObject("message", "welcome admin"+userDetails.getName());
			}
			else{
				mv=new ModelAndView("/index");
				session.setAttribute("category",category);
				session.setAttribute("categoryList", categoryDAO.list());
				mv.addObject("message","welcome"+userDetails.getName());
				cart=cartDAO.getCart(name);	
				mv.addObject("cart", cart);
				List<Cart> cartList=cartDAO.list(name);
				mv.addObject("cartList", cartList);
				mv.addObject("cartSize", cartList.size());
				
			}
		}
		else{
			mv=new ModelAndView("/login");
			mv.addObject("message","Invalid user");
		}
	return mv;
	}*/
	
	
	
	
	/*@RequestMapping(value="user/register", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute User userDetails){
		userDAO.saveOrUpdate(userDetails);
		ModelAndView mv=new ModelAndView("/index");
		mv.addObject("successMessage", "You Have Successfully Registered");
		return mv;
	}
	
	/*@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView mv = new ModelAndView("/index");
		session.invalidate();
		session = request.getSession(true);
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
	
		mv.addObject("logoutMessage", "You successfully logged out");
		mv.addObject("loggedOut", "true");
	
		return mv;
	 }*/
	@RequestMapping(value = "/login")
    public String login(@RequestParam(value="error", required = false) String error, @RequestParam(value="logout",
            required = false) String logout, Model model) {
        if (error!=null) {
        	System.out.println("Error.....");
            model.addAttribute("error", "...Invalid username and password");
        }
        	
        if(logout!=null) {
        	System.out.println("Logout called.....");
            model.addAttribute("msg", "...You have been logged out");
        }

        return "login";
    }
	
	   
    @RequestMapping(value = "/admin")
    public String adminManagement() 
    {
    	System.out.println("ADMIN CALLED.......");
    	return "adminhome";
    }
    
    @RequestMapping("/403")
    public String errorPage() 
    {
    	System.out.println("Error......");
    	return "403";
    }
    
    @RequestMapping(value = "/user")
    public String userManagement() 
    {
    	System.out.println("USER CALLED.......");
    	return "login";
    }
    @RequestMapping("/thanku")
    public String thanku() 
    {
    	System.out.println("THANK YOU");
    	return "thanku";
	
    }
  
    
}
















/*

package com.niit.shoppingcart1.controller;


import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.User;

@Controller
public class UserController {
	
	
@Autowired
UserDAO userDAO;
@Autowired
User userDetails;

@Autowired
Category category;

@Autowired
CategoryDAO categoryDAO;

@RequestMapping("/")
public ModelAndView onLoad(HttpSession session){
	ModelAndView mv=new ModelAndView("/index");
	session.setAttribute("category", category);
	session.setAttribute("categoryList", categoryDAO.list());
	System.out.println("loading");
	return mv;
}

@RequestMapping("/login")
public String getLogin(){
	return "login";
}

@RequestMapping("/about")
public String getAbout(){
	return "login";
}

@RequestMapping("/check")
public ModelAndView login(@RequestParam(name="name")String name,@RequestParam(name="password")String password,HttpSession session){
	ModelAndView mv;
	
	boolean isValidUser=userDAO.isValidUser(name, password);
	

	if(isValidUser){
		mv=new ModelAndView("/adminhome");
		
		userDetails=userDAO.getUser(name);
		session.setAttribute("loggedInUser",userDetails.getName());
		session.setAttribute("loggedInUserId",userDetails.getId());
		if(userDetails.getAdmin()==1){
			mv.addObject("message", "welcome admin"+userDetails.getName());
		}
		else{
			mv.addObject("message","welcome"+userDetails.getName());
		}
	}
	else{
		mv=new ModelAndView("/Fail");
		mv.addObject("message","Invalid user");
	}
return mv;
}



}
*/